import json
from pathlib import Path


def save_conversation(history: list[dict], path: str) -> None:
    """Serialize conversation history to a JSON file."""
    file_path = Path(path)
    file_path.parent.mkdir(parents=True, exist_ok=True)
    file_path.write_text(
        json.dumps(history, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def load_conversation(path: str) -> list[dict]:
    """Deserialize conversation history from a JSON file."""
    file_path = Path(path)
    if not file_path.exists():
        return []
    return json.loads(file_path.read_text(encoding="utf-8"))